const map = L.map('map').setView([37.961, -122.345], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: 'Map data © OpenStreetMap contributors'
}).addTo(map);

function addGeoLayer(file, color, type = 'circle') {
  fetch(`geojson/${file}`)
    .then(res => res.json())
    .then(data => {
      L.geoJSON(data, {
        pointToLayer: function (feature, latlng) {
          return type === 'line'
            ? null
            : L.circleMarker(latlng, {
                radius: 6,
                fillColor: color,
                color: color,
                weight: 1,
                fillOpacity: 0.9
              });
        },
        style: function () {
          return {
            color: color,
            weight: 3,
            opacity: 0.8
          };
        }
      }).addTo(map);
    })
    .catch(err => console.error(`Failed to load ${file}:`, err));
}

// Static layers
addGeoLayer('alpr-locations.geojson', '#ff0000');            // 🔴 ALPR Cameras
addGeoLayer('soundthinking.geojson', '#ffa500');             // 🟠 Gun Detection (SoundThinking)
addGeoLayer('camera-locations.geojson', '#000000');          // ⚫ Surveillance Cameras
addGeoLayer('cabinet-locations.geojson', '#3388ff');         // 🔵 Surveillance Cabinets
addGeoLayer('fiber-lines.geojson', '#800080', 'line');       // 🟣 Fiber Lines
addGeoLayer('streetlight-cameras.geojson', '#00CED1');       // 🔷 Streetlight Cameras
// Skipping mic-arrays.geojson — file not present



// Mobile units - loaded based on dropdown
const select = document.getElementById('mobileUnitsSelect');
let mobileLayer = null;

function loadMobileLayer(file) {
  if (mobileLayer) map.removeLayer(mobileLayer);
  fetch(`geojson/${file}`)
    .then(res => res.json())
    .then(data => {
      mobileLayer = L.geoJSON(data, {
        pointToLayer: (feature, latlng) =>
          L.circleMarker(latlng, {
            radius: 6,
            fillColor: '#ff69b4',
            color: '#ff69b4',
            weight: 1,
            fillOpacity: 0.9
          })
      }).addTo(map);
    })
    .catch(err => console.error(`Mobile data load failed: ${file}`, err));
}

// Initial load
loadMobileLayer(select.value);
select.addEventListener('change', () => {
  loadMobileLayer(select.value);
});
